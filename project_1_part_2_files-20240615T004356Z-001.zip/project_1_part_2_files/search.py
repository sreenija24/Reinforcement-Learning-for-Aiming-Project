import pickle
import json
from FOON_class import Object

# -----------------------------------------------------------------------------------------------------------------------------#

# Checks an ingredient exists in kitchen


def check_if_exist_in_kitchen(kitchen_items, ingredient):
    """
        parameters: a list of all kitchen items,
                    an ingredient to be searched in the kitchen
        returns: True if ingredient exists in the kitchen
    """

    for item in kitchen_items:
        if item["label"] == ingredient.label \
                and sorted(item["states"]) == sorted(ingredient.states) \
                and sorted(item["ingredients"]) == sorted(ingredient.ingredients) \
                and item["container"] == ingredient.container:
            return True

    return False


# -----------------------------------------------------------------------------------------------------------------------------#
def iterative_deepening_search(kitchen_items=[], goal_node=None):
    # list of indices of functional units
    reference_task_tree = []

    # list of object indices that need to be searched
    items_to_search = []

    # find the index of the goal node in object node list
    items_to_search.append(goal_node.id)
    # print(foon_object_nodes[items_to_search])
    # list of item already explored
    items_already_searched = []

    while len(items_to_search) > 0:
        current_item_idx = items_to_search.pop(0)  # pop the first element
        if current_item_idx in items_already_searched:
            continue
        else:
            items_already_searched.append(current_item_idx)

        current_item = foon_object_nodes[current_item_idx]

        if not check_if_exist_in_kitchen(kitchen_items, current_item):
            candidate_units = foon_object_to_FU_map[current_item_idx]
            # selecting the first path
            # this is the part where you should use heuristic for Greedy Best-First search
            selected_candidate_idx = candidate_units[0]

            # if a FU is already taken, do not process it again
            if selected_candidate_idx in reference_task_tree:
                continue

            reference_task_tree.append(selected_candidate_idx)
            
            input_nodes = foon_functional_units[selected_candidate_idx].input_nodes 
            for node in input_nodes: # Iterate over input_nodes of selected_functional_units.
                node_index = node.id
                if node_index not in items_to_search: # check if the node exists in items_to_search list
                    # if there exists a utensil,we are only exploring the ingredients in it ,leaving the utensil
                    flag = True
                    if node.label in utensils and len(node.ingredients) == 1: # check if the input node is a utensil and if it is then check it contains ingredients or not
                        for node2 in input_nodes: # iterate over input_nodes

                            #checking whether the first element of ingredients is same as the node
                            #check if the utensil is same as the container which has the node
                            if node2.label == node.ingredients[0] and node2.container == node.label:
                                flag = False 
                                break
                    if flag: #if flag is true
                        if(input_nodes): # if length of input_nodes is greater than zero
                            candidate_ids=[]
                            for node in input_nodes: # iterate over input nodes
                                candidate_ids.append(node.id) # append the node ids
                            items_to_search = candidate_ids + items_to_search # increment the items_to_search list with new_ids
                        else:
                            items_to_search.append(node_index) # append the node_index to the items to search list
    # reverse the task tree
    reference_task_tree.reverse()
    # create a list of functional units from reference_task_tree indices
    task_tree_list = []
    for each_fu in reference_task_tree:
        task_tree_list.append(foon_functional_units[each_fu])
    return task_tree_list

def h1_search(kitchen_items=[], goal_node=None):
    # list of indices of functional units
    reference_task_tree = []

    # list of object indices that need to be searched
    items_to_search = []

    # find the index of the goal node in object node list
    items_to_search.append(goal_node.id)

    # list of item already explored
    items_already_searched = []

    while len(items_to_search) > 0:
        current_item_index = items_to_search.pop(0)  # pop the first element
        if current_item_index in items_already_searched:
            continue

        else:
            items_already_searched.append(current_item_index)

        current_item = foon_object_nodes[current_item_index]

        if not check_if_exist_in_kitchen(kitchen_items, current_item):

            candidate_units = foon_object_to_FU_map[current_item_index]

            # selecting the first path
            # this is the part where you should use heuristic for Greedy Best-First search
            foon_motion_successrate = {}
            for fu_unit in candidate_units: # Iterating through FU indexes
                foon_motion_successrate[fu_unit] = foon_functional_units[fu_unit].motion_node # {assigning the motion of the functional unit}
                foon_motion_successrate[fu_unit] = actions[foon_motion_successrate[fu_unit]] #{Replacing the motion value with Motion successrate}
                max_successrate = max(foon_motion_successrate.values()) # selecting a FU that has high successrate
                for key, val in foon_motion_successrate.items(): #Iterating through The FU motion successrates
                    if val == max_successrate: # If it matches
                        selected_candidate_idx = key # Select the FU index

            # if an fu is already taken, do not explore it again
            if selected_candidate_idx in reference_task_tree:
                continue

            reference_task_tree.append(selected_candidate_idx)

            # all input of the selected FU need to be explored
            for node in foon_functional_units[
                    selected_candidate_idx].input_nodes:
                node_index = node.id
                if node_index not in items_to_search:

                    #avoiding duplicates and only exploring the non duplicate objects by cross checking the input nodes
                    flag = True
                    if node.label in utensils and len(node.ingredients) == 1:
                        for node2 in foon_functional_units[
                                selected_candidate_idx].input_nodes:
                            if node2.label == node.ingredients[
                                    0] and node2.container == node.label:

                                flag = False
                                break
                    if flag:
                        items_to_search.append(node_index)

    # reverse the task tree
    reference_task_tree.reverse()

    # create a list of functional unit from reference_task_tree indices
    task_tree_list = []
    for each_fu in reference_task_tree:
        task_tree_list.append(foon_functional_units[each_fu])

    return task_tree_list

def h2_search(kitchen_items=[], goal_node=None):
    # list of indices of functional units
    reference_task_tree = []

    # list of object indices that need to be searched
    items_to_search = []

    # find the index of the goal node in object node list
    items_to_search.append(goal_node.id)

    # list of item already explored
    items_already_searched = []

    while len(items_to_search) > 0:
        current_item_index = items_to_search.pop(0)  # pop the first element
        if current_item_index in items_already_searched:
            continue

        else:
            items_already_searched.append(current_item_index)

        current_item = foon_object_nodes[current_item_index]

        if not check_if_exist_in_kitchen(kitchen_items, current_item):

            candidate_units = foon_object_to_FU_map[current_item_index] #candidate units is list of all functional units
            # selecting the first path
            # this is the part where you should use heuristic for Greedy Best-First search
            fu_input_nodes = {} # Initializing an empty dictionary to store functional unit index and its num of input_nodes
            for each_fu in candidate_units: #iterating through all the functional unit's indexes 
                input_nodes = foon_functional_units[each_fu].input_nodes
                fu_input_nodes[each_fu] = len(input_nodes) # assigning no of input nodes to each_functional_unit
                for node in input_nodes: # Iterating through every input node
                    no_of_ingredients = len(node.ingredients)
                    if no_of_ingredients > 0:
                        fu_input_nodes[each_fu] += len(node.ingredients) - 1 # Incrementing the number of input_nodes with ingredients excluding the utensil
            min_of_input_objects = min(fu_input_nodes.values()) # picking the minimum input objects+ingredients among all functional units.
            for key, val in fu_input_nodes.items(): # iterating through fu_input_nodes
                if val == min_of_input_objects: # if the num_of_input objects value is equal to min value.
                    selected_candidate_idx = key # assign that functional_unit index to selected_candidate_idx

            # if an fu is already taken, do not process it again
            if selected_candidate_idx in reference_task_tree:
                continue

            reference_task_tree.append(selected_candidate_idx)

            # all input of the selected FU need to be explored
            for node in foon_functional_units[
                    selected_candidate_idx].input_nodes:
                node_index = node.id
                if node_index not in items_to_search:

                    # avoiding the duplicates in input nodes
                    flag = True
                    if node.label in utensils and len(node.ingredients) == 1:
                        for node2 in foon_functional_units[
                                selected_candidate_idx].input_nodes:
                            if node2.label == node.ingredients[
                                    0] and node2.container == node.label:

                                flag = False
                                break
                    if flag:
                        items_to_search.append(node_index)

    # reverse the task tree
    reference_task_tree.reverse()

    # create a list of functional unit from the indices of reference_task_tree
    task_tree_list = []
    for eachunit in reference_task_tree:
        task_tree_list.append(foon_functional_units[eachunit])

    return task_tree_list


def save_paths_to_file(task_tree, path):

    print('writing generated task tree to ', path)
    _file = open(path, 'w')

    _file.write('//\n')
    for FU in task_tree:
        _file.write(FU.get_FU_as_text() + "\n")
    _file.close()


# -----------------------------------------------------------------------------------------------------------------------------#

# creates the graph using adjacency list
# each object has a list of functional list where it is an output


def read_universal_foon(filepath='FOON.pkl'):
    """
        parameters: path of universal foon (pickle file)
        returns: a map. key = object, value = list of functional units
    """
    pickle_data = pickle.load(open(filepath, 'rb'))
    functional_units = pickle_data["functional_units"]
    object_nodes = pickle_data["object_nodes"]
    object_to_FU_map = pickle_data["object_to_FU_map"]

    return functional_units, object_nodes, object_to_FU_map


# -----------------------------------------------------------------------------------------------------------------------------#

if __name__ == '__main__':
    foon_functional_units, foon_object_nodes, foon_object_to_FU_map = read_universal_foon(
    )
    actions = dict()
    with open("motion.txt") as file:
        for txt_line in file:
            if txt_line == "\n":
                break
            else:
                key, val = txt_line.split("\t")
                actions[key] = float(val.strip("\n"))
    
    utensils = []
    with open('utensils.txt', 'r') as f:
        for line in f:
            utensils.append(line.rstrip())

    kitchen_items = json.load(open('kitchen.json'))

    goal_nodes = json.load(open("goal_nodes.json"))

    for node in goal_nodes:
        node_object = Object(node["label"])
        node_object.states = node["states"]
        node_object.ingredients = node["ingredients"]
        node_object.container = node["container"]

        for object in foon_object_nodes:
            if object.check_object_equal(node_object):
                
                                   
                output_task_tree = iterative_deepening_search(kitchen_items, object)
                save_paths_to_file(output_task_tree,
                                   'output_iterative_deepening_search_{}.txt'.format(node["label"]))
                
                output_task_tree = h1_search(kitchen_items, object)
                save_paths_to_file(output_task_tree,
                                   'output_h1_search_{}.txt'.format(node["label"]))

                output_task_tree = h2_search(kitchen_items, object)
                save_paths_to_file(output_task_tree,
                                   'output_h2_search_{}.txt'.format(node["label"]))
                
                break
